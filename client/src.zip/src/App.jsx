import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Signup from './pages/Signup';
import Login from './pages/Login';
import Profile from './pages/Profile';
import ChangeProfile from './pages/ChangeProfile';
import DashboardLayout from './layouts/DashboardLayout';
import Analytics from './pages/Analytics';
import Products from './pages/Products';
import Cart from './pages/Cart';
import Orders from './pages/Orders';
import Demand from './pages/Demand';
import AddProduct from './pages/AddProduct';

function App() {
  return (
    <Router>
      <Navbar />
      <div >
        <Routes>
          
          <Route path="/signup" element={<Signup />} />
          <Route path="/" element={<Login />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/change-profile" element={<ChangeProfile />} />

          {/* Dashboard route with nested routes */}
          <Route path="/dashboard" element={<DashboardLayout />}>
            <Route path="analytics" element={<Analytics />} />
            <Route path="products" element={<Products />} />
            <Route path="cart" element={<Cart />} />
            <Route path="orders" element={<Orders />} />
            <Route path="demand" element={<Demand />} />
            <Route path="addproduct" element={<AddProduct />} />
            <Route path="add-product/:id" element={<AddProduct />} />
          </Route>
        </Routes>
      </div>
    </Router>
  );
}

export default App;
