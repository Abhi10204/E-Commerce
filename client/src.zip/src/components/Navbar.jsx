import React, { useState, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';

const Navbar = () => {
  const navigate = useNavigate();
  const [showDropdown, setShowDropdown] = useState(false);
  const dropdownRef = useRef(null);

  const isAuthenticated = localStorage.getItem('authToken');
  const user = JSON.parse(localStorage.getItem('user'));
  const profilePic = user?.profilePicture || 'https://www.svgrepo.com/show/382106/avatar-boy.svg';

  const handleLogout = () => {
    localStorage.removeItem('authToken');
    localStorage.removeItem('user');
    setShowDropdown(false);
    navigate('/');
  };

  return (
    <nav className="bg-gray-800 text-white px-6 py-4 flex justify-between items-center sticky top-0 z-50 shadow-md">
      <h2 className="text-2xl font-bold">MyApp</h2>
      <div className="flex space-x-6 items-center">
        {isAuthenticated ? (
          <>
            <Link to="/dashboard" className="hover:text-gray-300">Dashboard</Link>
            <div className="relative" ref={dropdownRef}>
              <img
                src={profilePic}
                alt="Profile"
                className="w-10 h-10 rounded-full cursor-pointer border-2 border-purple-500"
                onClick={() => setShowDropdown(!showDropdown)}
              />
              {showDropdown && (
                <div className="absolute right-0 mt-2 w-48 bg-white text-gray-800 rounded shadow-lg z-50">
                  <button
                    onClick={() => navigate('/profile')}
                    className="block px-4 py-2 hover:bg-gray-100 w-full text-left"
                  >
                    View Profile
                  </button>
                  <button
                    onClick={() => navigate('/change-profile')}
                    className="block px-4 py-2 hover:bg-gray-100 w-full text-left"
                  >
                    Change Profile
                  </button>
                  <button
                    onClick={handleLogout}
                    className="block px-4 py-2 hover:bg-gray-100 w-full text-left"
                  >
                    Logout
                  </button>
                </div>
              )}
            </div>
          </>
        ) : (
          <>
            <Link to="/" className="hover:text-gray-300">Login</Link>
            <Link to="/signup" className="hover:text-gray-300">Signup</Link>
          </>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
