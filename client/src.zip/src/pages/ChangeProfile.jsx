// pages/ChangeProfile.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const ChangeProfile = () => {
  const navigate = useNavigate();
  const storedUser = JSON.parse(localStorage.getItem('user'));

  const [name, setName] = useState(storedUser?.name || '');
  const [profilePicture, setProfilePicture] = useState(null);

  const handleUpdate = async () => {
    const formData = new FormData();
    formData.append('name', name);
    if (profilePicture) {
      formData.append('profilePicture', profilePicture);
    }

    try {
      const token = localStorage.getItem('authToken');
      const res = await axios.put('http://localhost:5000/api/users/update', formData, {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'multipart/form-data',
        },
      });

      localStorage.setItem('user', JSON.stringify(res.data.user));
      navigate('/profile');
    } catch (err) {
      console.error('Update failed:', err);
    }
  };

  return (
    <div className="max-w-md mx-auto p-6 bg-white rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-4">Edit Profile</h2>
      <input
        type="text"
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="Name"
        className="w-full mb-4 px-4 py-2 border border-gray-300 rounded-md"
      />
      <input
        type="file"
        accept="image/*"
        onChange={(e) => setProfilePicture(e.target.files[0])}
        className="w-full mb-4"
      />
      <button
        onClick={handleUpdate}
        className="w-full bg-purple-600 hover:bg-purple-700 text-white font-semibold py-2 rounded-md"
      >
        Save Changes
      </button>
    </div>
  );
};

export default ChangeProfile;
