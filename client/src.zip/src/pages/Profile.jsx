// pages/Profile.jsx
import React from 'react';

const Profile = () => {
  const user = JSON.parse(localStorage.getItem('user'));

  return (
    <div className="max-w-md mx-auto p-6 bg-white rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-4">Your Profile</h2>
      <div className="flex flex-col items-center space-y-4">
        <img
          src={user?.profilePicture || 'https://www.svgrepo.com/show/382106/avatar-boy.svg'}
          alt="Profile"
          className="w-24 h-24 rounded-full border-2 border-purple-500"
        />
        <p><strong>Name:</strong> {user?.name}</p>
        <p><strong>Email:</strong> {user?.email}</p>
      </div>
    </div>
  );
};

export default Profile;
