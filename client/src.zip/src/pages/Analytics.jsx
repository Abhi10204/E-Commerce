import React from 'react';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid,
  LineChart, Line, Legend, ResponsiveContainer
} from 'recharts';

const Analytics = () => {
  // Mock data – replace with real data from API later
  const purchaseData = [
    { name: 'Atul', products: 5 },
    { name: 'Akshat', products: 9 },
    { name: 'Om', products: 4 },
    { name: 'David', products: 6 },
  ];

  const orderData = [
    { name: 'Atul', orders: 3 },
    { name: 'Akshat', orders: 7 },
    { name: 'Om', orders: 2 },
    { name: 'Ajay', orders: 5 },
  ];

  return (
    <div className="p-6 space-y-10">
      <h1 className="text-3xl font-bold mb-6">📊 Analytics Dashboard</h1>

      {/* First Graph: Product Purchases */}
      <div className="bg-white p-4 rounded-xl shadow-md">
        <h2 className="text-xl font-semibold mb-4">Products Purchased by Users</h2>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={purchaseData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="products" fill="#6366f1" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Second Graph: Orders per User */}
      <div className="bg-white p-4 rounded-xl shadow-md">
        <h2 className="text-xl font-semibold mb-4">Total Orders per User</h2>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={orderData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="orders" stroke="#10b981" strokeWidth={3} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default Analytics;
