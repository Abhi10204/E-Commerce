import React from 'react';

const Orders = () => {
  return <h1 className="text-3xl font-semibold">Orders</h1>;
};

export default Orders;