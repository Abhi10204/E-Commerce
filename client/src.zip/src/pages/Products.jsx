import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { Edit, Trash2, ShoppingCart } from "lucide-react";

const Products = () => {
  const [products, setProducts] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [selectedProductId, setSelectedProductId] = useState(null);
  const [successMessage, setSuccessMessage] = useState("");
  const [detailModal, setDetailModal] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [cart, setCart] = useState(() => {
    const savedCart = localStorage.getItem("cart");
    return savedCart ? JSON.parse(savedCart) : [];
  });

  const navigate = useNavigate();

  useEffect(() => {
    fetchProducts();
  }, []);

  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(cart));
  }, [cart]);

  const fetchProducts = async () => {
    try {
      const token = localStorage.getItem("authToken");
      const res = await axios.get("http://localhost:5000/api/products", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setProducts(res.data);
    } catch (err) {
      console.error("Error fetching products:", err);
    }
  };

  const confirmDelete = (id) => {
    setSelectedProductId(id);
    setShowModal(true);
  };

  const handleDelete = async () => {
    try {
      const token = localStorage.getItem("authToken");
      await axios.delete(`http://localhost:5000/api/products/${selectedProductId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setProducts(products.filter((product) => product._id !== selectedProductId));
      setSuccessMessage("Product deleted successfully!");
      setShowModal(false);
      setSelectedProductId(null);
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (err) {
      console.error("Error deleting product:", err);
    }
  };

  const handleAddToCart = (product) => {
    const existingIndex = cart.findIndex((item) => item._id === product._id);
    let updatedCart = [...cart];

    if (existingIndex >= 0) {
      updatedCart[existingIndex].quantity += 1;
    } else {
      updatedCart.push({
        _id: product._id,
        title: product.title,
        price: product.price,
        imageUrl: product.imageUrl,
        quantity: 1,
      });
    }

    setCart(updatedCart);
    setSuccessMessage(`${product.title} added to cart!`);
    setTimeout(() => setSuccessMessage(""), 3000);
  };

  const openDetailModal = (product) => {
    setSelectedProduct(product);
    setDetailModal(true);
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Products Manager</h1>
        <div className="flex gap-4">
          <button
            onClick={() => navigate("/dashboard/addproduct")}
            className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700"
          >
            Add Product
          </button>
          <button
            onClick={() => navigate("/dashboard/cart")}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center gap-1"
          >
            <ShoppingCart size={16} />
            Cart
          </button>
        </div>
      </div>

      {successMessage && (
        <div className="bg-green-500 text-white p-4 rounded-lg mb-4 text-center">
          {successMessage}
        </div>
      )}

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {products.map((product) => (
          <div
            key={product._id}
            className="bg-white shadow-xl rounded-2xl p-4 flex flex-col cursor-pointer hover:shadow-2xl transition"
            onClick={() => openDetailModal(product)}
          >
            {product.imageUrl && (
              <img
                src={product.imageUrl}
                alt={product.title}
                className="w-full h-48 object-cover rounded-lg mb-3"
              />
            )}
            <h2 className="text-xl font-semibold">{product.title}</h2>
            <p className="text-gray-600 mb-2">${product.price}</p>
            <p className="text-sm text-gray-500 mb-4">
              {product.description.length > 100
                ? product.description.substring(0, 100) + "..."
                : product.description}
            </p>
            <div
              className="mt-auto flex justify-between space-x-2"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => navigate(`/dashboard/add-product/${product._id}`)}
                className="flex items-center gap-1 bg-yellow-400 text-white px-3 py-1 rounded hover:bg-yellow-500"
              >
                <Edit size={16} />
                <span>Edit</span>
              </button>
              <button
                onClick={() => confirmDelete(product._id)}
                className="flex items-center gap-1 bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600"
              >
                <Trash2 size={16} />
                <span>Delete</span>
              </button>
              <button
                onClick={() => handleAddToCart(product)}
                className="flex items-center gap-1 bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600"
              >
                <ShoppingCart size={16} />
                <span>Add</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-xl shadow-2xl max-w-md w-full">
            <h2 className="text-xl font-bold mb-4">Are you sure?</h2>
            <p className="mb-6 text-gray-700">Do you really want to delete this product?</p>
            <div className="flex justify-end space-x-4">
              <button
                onClick={() => setShowModal(false)}
                className="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400"
              >
                No
              </button>
              <button
                onClick={handleDelete}
                className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
              >
                Yes
              </button>
            </div>
          </div>
        </div>
      )}

      {detailModal && selectedProduct && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50">
          <div className="relative bg-white p-6 rounded-xl shadow-2xl max-w-lg w-full">
            <button
              onClick={() => setDetailModal(false)}
              className="absolute top-2 right-2 text-gray-500 hover:text-red-500 text-xl font-bold"
            >
              &times;
            </button>
            <h2 className="text-2xl font-bold mb-2">{selectedProduct.title}</h2>
            <img
              src={selectedProduct.imageUrl}
              alt={selectedProduct.title}
              className="w-full h-64 object-cover rounded mb-4"
            />
            <p className="text-gray-700 mb-2">Price: ${selectedProduct.price}</p>
            <p className="text-gray-600 mb-4">{selectedProduct.description}</p>
            <div className="text-right">
              <button
                onClick={() => setDetailModal(false)}
                className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Products;
