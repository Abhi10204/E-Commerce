import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";

const AddProduct = () => {
  const [form, setForm] = useState({ title: "", price: "", description: "", imageUrl: "" });
  const [successMessage, setSuccessMessage] = useState(""); // New state for success message
  const navigate = useNavigate();
  const { id } = useParams();

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const token = localStorage.getItem("authToken");
        const res = await axios.get(`http://localhost:5000/api/products/${id}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setForm(res.data);
      } catch (err) {
        console.error("Error fetching product:", err);
      }
    };

    if (id) fetchProduct();
  }, [id]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem("authToken");
    try {
      if (id) {
        await axios.put(`http://localhost:5000/api/products/${id}`, form, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setSuccessMessage("Product updated successfully!"); // Success message for update
      } else {
        await axios.post("http://localhost:5000/api/products", form, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setSuccessMessage("Product added successfully!"); // Success message for add
      }
      setTimeout(() => setSuccessMessage(""), 3000); // Hide the message after 3 seconds
      navigate("/dashboard/products");
    } catch (err) {
      console.error("Error submitting product:", err);
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-6 text-center">
        {id ? "Edit Product" : "Add Product"}
      </h1>

      {/* Display success message */}
      {successMessage && (
        <div className="bg-green-500 text-white p-4 rounded-lg mb-4 text-center">
          {successMessage}
        </div>
      )}

      <form
        onSubmit={handleSubmit}
        className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-white p-6 shadow-lg rounded-2xl"
      >
        <input
          type="text"
          name="title"
          placeholder="Title"
          value={form.title}
          onChange={handleChange}
          className="border p-2 rounded-lg"
          required
        />
        <input
          type="number"
          name="price"
          placeholder="Price"
          value={form.price}
          onChange={handleChange}
          className="border p-2 rounded-lg"
          required
        />
        <input
          type="text"
          name="imageUrl"
          placeholder="Image URL"
          value={form.imageUrl}
          onChange={handleChange}
          className="border p-2 rounded-lg"
          required
        />
        <input
          type="text"
          name="description"
          placeholder="Description"
          value={form.description}
          onChange={handleChange}
          className="border p-2 rounded-lg"
          required
        />
        <button
          type="submit"
          className="md:col-span-2 bg-blue-600 text-white rounded-lg py-2 hover:bg-blue-700 transition"
        >
          {id ? "Update Product" : "Add Product"}
        </button>
      </form>
    </div>
  );
};

export default AddProduct;
