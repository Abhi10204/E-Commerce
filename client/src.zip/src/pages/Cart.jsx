import React, { useState, useEffect } from "react";
import { Trash2 } from "lucide-react";

const Cart = () => {
  const [cart, setCart] = useState([]);

  useEffect(() => {
    const savedCart = localStorage.getItem("cart");
    if (savedCart) setCart(JSON.parse(savedCart));
  }, []);

  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(cart));
  }, [cart]);

  const updateQuantity = (productId, amount) => {
    setCart((prevCart) => {
      return prevCart
        .map((item) =>
          item._id === productId ? { ...item, quantity: item.quantity + amount } : item
        )
        .filter((item) => item.quantity > 0); // Remove if quantity is 0
    });
  };

  const removeItem = (productId) => {
    setCart((prevCart) => prevCart.filter((item) => item._id !== productId));
  };

  const getTotalPrice = () => {
    return cart
      .reduce((acc, item) => acc + (item.price || 0) * (item.quantity || 1), 0)
      .toFixed(2);
  };

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">Your Cart</h1>
      {cart.length === 0 ? (
        <p className="text-gray-600">Cart is empty.</p>
      ) : (
        cart.map((item) => (
          <div
            key={item._id}
            className="flex justify-between items-center p-4 mb-3 bg-white shadow rounded-lg"
          >
            <div className="flex gap-4 items-center">
              <img src={item.imageUrl} alt={item.title} className="w-16 h-16 object-cover rounded" />
              <div>
                <h2 className="text-lg font-semibold">{item.title}</h2>
                <p className="text-gray-600">${item.price}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => updateQuantity(item._id, -1)}
                className="bg-gray-200 px-2 py-1 rounded hover:bg-gray-300"
              >
                -
              </button>
              <span>{item.quantity}</span>
              <button
                onClick={() => updateQuantity(item._id, 1)}
                className="bg-gray-200 px-2 py-1 rounded hover:bg-gray-300"
              >
                +
              </button>
              <button
                onClick={() => removeItem(item._id)}
                className="bg-red-500 text-white px-2 py-1 rounded hover:bg-red-600"
              >
                <Trash2 size={16} />
              </button>
            </div>
          </div>
        ))
      )}
      {cart.length > 0 && (
        <div className="mt-6 flex justify-between text-xl font-semibold">
          <span>Total:</span>
          <span>${getTotalPrice()}</span>
        </div>
      )}
    </div>
  );
};

export default Cart;
