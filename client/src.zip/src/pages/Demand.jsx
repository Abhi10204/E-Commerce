import React from 'react';

const Demand = () => {
  return <h1 className="text-3xl font-semibold">Demand</h1>;
};

export default Demand;